package com.example

import android.content.Context
import androidx.test.core.app.ApplicationProvider
import com.example.data.IconByteVault
import com.example.sdk.ActivationStatus
import com.example.sdk.MetaActivationManager
import com.example.ui.AarBinaryInspector
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertTrue
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [36])
class ExampleRobolectricTest {

    @Test
    fun `read app_name and verify compiled MetaActivationManager aar SDK and separated ui`() {
        val context = ApplicationProvider.getApplicationContext<Context>()
        val appName = context.getString(R.string.app_name)
        assertEquals("CloneVault", appName)

        // Verify MetaActivationManager SDK singleton loaded from meta-activation-sdk.aar
        val activated = MetaActivationManager.activateSdk("META-CORE-2026-ENT-994A")
        assertTrue(activated)
        assertEquals(ActivationStatus.ACTIVE, MetaActivationManager.getActivationStatus())
        assertEquals("meta-activation-sdk.aar", MetaActivationManager.getAarArchiveInfo().aarFileName)

        val launchSession = MetaActivationManager.launchApp("com.example.targetapp")
        assertNotNull(launchSession)

        // Verify compiled .aar binary inspection from separated ui(src)
        val aarReport = AarBinaryInspector.inspectCompiledAar(context)
        assertTrue(aarReport.isVerified)

        // Verify ByteArray icon generation and decoding
        val bytes = IconByteVault.generateIsolatedBadgeIconBytes("CV", 0xFF06B6D4.toInt(), 0xFF6366F1.toInt())
        assertTrue(bytes.isNotEmpty())
        val decoded = IconByteVault.byteArrayToImageBitmap(bytes)
        assertNotNull(decoded)
    }
}
