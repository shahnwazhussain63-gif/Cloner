package com.example.data

import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Canvas
import android.graphics.LinearGradient
import android.graphics.Paint
import android.graphics.RectF
import android.graphics.Shader
import android.graphics.Typeface
import android.graphics.drawable.Drawable
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.asImageBitmap
import java.io.ByteArrayOutputStream
import java.security.MessageDigest
import java.util.Locale

/**
 * Handles strict Data Segregation for cloned application icons.
 * Instead of holding or rendering raw `Drawable` references tied to the host `PackageManager`
 * resource tree, `IconByteVault` extracts pixel data into an isolated PNG `ByteArray`,
 * recycles intermediate bitmaps immediately, and reconstructs `ImageBitmap` instances purely
 * from segregated byte arrays.
 */
object IconByteVault {

    private const val DEFAULT_ICON_SIZE_PX = 144

    /**
     * Extracts a `Drawable` into an isolated PNG-compressed `ByteArray` and immediately
     * releases intermediate native bitmap memory so no `Drawable` tree reference persists.
     */
    fun drawableToByteArray(drawable: Drawable, maxSizePx: Int = DEFAULT_ICON_SIZE_PX): ByteArray {
        val width = drawable.intrinsicWidth.coerceAtLeast(1).coerceAtMost(maxSizePx)
        val height = drawable.intrinsicHeight.coerceAtLeast(1).coerceAtMost(maxSizePx)
        val bitmap = Bitmap.createBitmap(width, height, Bitmap.Config.ARGB_8888)
        return try {
            val canvas = Canvas(bitmap)
            drawable.setBounds(0, 0, canvas.width, canvas.height)
            drawable.draw(canvas)
            val outputStream = ByteArrayOutputStream(4096)
            bitmap.compress(Bitmap.CompressFormat.PNG, 100, outputStream)
            outputStream.toByteArray()
        } catch (e: Exception) {
            generateIsolatedBadgeIconBytes("APP", 0xFF06B6D4.toInt(), 0xFF6366F1.toInt())
        } finally {
            if (!bitmap.isRecycled) {
                bitmap.recycle()
            }
        }
    }

    /**
     * Decodes an isolated `ByteArray` back into a Compose `ImageBitmap` without touching
     * `PackageManager` or system `Resources`.
     */
    fun byteArrayToImageBitmap(bytes: ByteArray?): ImageBitmap? {
        if (bytes == null || bytes.isEmpty()) return null
        return try {
            val options = BitmapFactory.Options().apply {
                inPreferredConfig = Bitmap.Config.ARGB_8888
            }
            val decoded = BitmapFactory.decodeByteArray(bytes, 0, bytes.size, options)
            decoded?.asImageBitmap()
        } catch (e: Exception) {
            null
        }
    }

    /**
     * Generates a high-contrast isolated `ByteArray` icon badge for pre-seeded sandbox templates
     * or fallback packages.
     */
    fun generateIsolatedBadgeIconBytes(
        monogram: String,
        startColorArgb: Int,
        endColorArgb: Int,
        sizePx: Int = DEFAULT_ICON_SIZE_PX
    ): ByteArray {
        val bitmap = Bitmap.createBitmap(sizePx, sizePx, Bitmap.Config.ARGB_8888)
        return try {
            val canvas = Canvas(bitmap)
            val rect = RectF(4f, 4f, sizePx - 4f, sizePx - 4f)
            val cornerRadius = sizePx * 0.26f

            val bgPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
                shader = LinearGradient(
                    0f,
                    0f,
                    sizePx.toFloat(),
                    sizePx.toFloat(),
                    startColorArgb,
                    endColorArgb,
                    Shader.TileMode.CLAMP
                )
            }
            canvas.drawRoundRect(rect, cornerRadius, cornerRadius, bgPaint)

            val borderPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
                style = Paint.Style.STROKE
                strokeWidth = 3.5f
                color = 0x55FFFFFF
            }
            canvas.drawRoundRect(rect, cornerRadius, cornerRadius, borderPaint)

            val textPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
                color = 0xFFFFFFFF.toInt()
                textSize = sizePx * 0.40f
                typeface = Typeface.create(Typeface.SANS_SERIF, Typeface.BOLD)
                textAlign = Paint.Align.CENTER
            }
            val textY = (sizePx / 2f) - ((textPaint.descent() + textPaint.ascent()) / 2f)
            canvas.drawText(monogram.take(2).uppercase(Locale.US), sizePx / 2f, textY, textPaint)

            val outputStream = ByteArrayOutputStream(4096)
            bitmap.compress(Bitmap.CompressFormat.PNG, 100, outputStream)
            outputStream.toByteArray()
        } finally {
            if (!bitmap.isRecycled) {
                bitmap.recycle()
            }
        }
    }

    /**
     * Computes a compact SHA-256 hex fingerprint of the icon `ByteArray` to verify memory segregation.
     */
    fun computeByteSignature(bytes: ByteArray): String {
        if (bytes.isEmpty()) return "0x00000000"
        return try {
            val digest = MessageDigest.getInstance("SHA-256").digest(bytes)
            val hex = digest.take(4).joinToString("") { "%02X".format(it) }
            "0x$hex"
        } catch (e: Exception) {
            "0x%08X".format(bytes.contentHashCode())
        }
    }

    /**
     * Formats the `ByteArray` length in human-readable KB for data segregation telemetry.
     */
    fun formatByteSize(byteCount: Int): String {
        if (byteCount <= 0) return "0 B"
        val kb = byteCount / 1024.0
        return String.format(Locale.US, "%.1f KB BLOB", kb)
    }
}
