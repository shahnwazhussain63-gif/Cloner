package com.example.data

import android.content.Context
import androidx.room.ColumnInfo
import androidx.room.Dao
import androidx.room.Database
import androidx.room.Entity
import androidx.room.Index
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.PrimaryKey
import androidx.room.Query
import androidx.room.Room
import androidx.room.RoomDatabase
import kotlinx.coroutines.flow.Flow

/**
 * Represents an isolated multi-account profile container (e.g., "Account #1", "Account #2").
 */
@Entity(tableName = "profile_containers")
data class ProfileContainerEntity(
    @PrimaryKey val profileId: String,
    val displayName: String,
    val environmentTag: String,
    val accentColorHex: Long,
    val createdAt: Long = System.currentTimeMillis()
)

/**
 * Represents a cloned app instance inside a specific `profileId` container.
 * Notice `iconBytes` is stored strictly as a `ByteArray` BLOB to enforce runtime memory segregation.
 */
@Entity(
    tableName = "cloned_apps",
    indices = [
        Index(value = ["profileId", "packageName"], unique = true)
    ]
)
data class ClonedAppEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val profileId: String,
    val packageName: String,
    val appName: String,
    val versionName: String,
    val isSystemApp: Boolean = false,
    @ColumnInfo(typeAffinity = ColumnInfo.BLOB)
    val iconBytes: ByteArray,
    val iconByteHash: String,
    val iconByteSize: Int,
    val clonedAt: Long = System.currentTimeMillis(),
    val launchCount: Int = 0,
    val lastLaunchedAt: Long? = null
) {
    override fun equals(other: Any?): Boolean {
        if (this === other) return true
        if (other !is ClonedAppEntity) return false
        return id == other.id &&
            profileId == other.profileId &&
            packageName == other.packageName &&
            appName == other.appName &&
            versionName == other.versionName &&
            iconByteHash == other.iconByteHash &&
            launchCount == other.launchCount &&
            lastLaunchedAt == other.lastLaunchedAt
    }

    override fun hashCode(): Int {
        var result = id.hashCode()
        result = 31 * result + profileId.hashCode()
        result = 31 * result + packageName.hashCode()
        result = 31 * result + iconByteHash.hashCode()
        result = 31 * result + launchCount
        return result
    }
}

@Dao
interface CloneVaultDao {

    @Query("SELECT * FROM profile_containers ORDER BY createdAt ASC")
    fun observeAllProfiles(): Flow<List<ProfileContainerEntity>>

    @Query("SELECT COUNT(*) FROM profile_containers")
    suspend fun getProfileCount(): Int

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertProfile(profile: ProfileContainerEntity)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertProfiles(profiles: List<ProfileContainerEntity>)

    @Query("SELECT * FROM cloned_apps WHERE profileId = :profileId ORDER BY appName COLLATE NOCASE ASC")
    fun observeClonedAppsForProfile(profileId: String): Flow<List<ClonedAppEntity>>

    @Query("SELECT * FROM cloned_apps ORDER BY clonedAt DESC")
    fun observeAllClonedApps(): Flow<List<ClonedAppEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertClonedApp(app: ClonedAppEntity): Long

    @Insert(onConflict = OnConflictStrategy.IGNORE)
    suspend fun insertClonedApps(apps: List<ClonedAppEntity>)

    @Query("DELETE FROM cloned_apps WHERE id = :cloneId")
    suspend fun deleteClonedAppById(cloneId: Long)

    @Query("DELETE FROM cloned_apps WHERE profileId = :profileId AND packageName = :packageName")
    suspend fun deleteClonedAppByPackage(profileId: String, packageName: String)

    @Query("UPDATE cloned_apps SET launchCount = launchCount + 1, lastLaunchedAt = :timestamp WHERE id = :cloneId")
    suspend fun recordCloneLaunch(cloneId: Long, timestamp: Long = System.currentTimeMillis())
}

@Database(
    entities = [ProfileContainerEntity::class, ClonedAppEntity::class],
    version = 1,
    exportSchema = false
)
abstract class CloneVaultDatabase : RoomDatabase() {

    abstract fun cloneVaultDao(): CloneVaultDao

    companion object {
        @Volatile
        private var INSTANCE: CloneVaultDatabase? = null

        fun getInstance(context: Context): CloneVaultDatabase {
            return INSTANCE ?: synchronized(this) {
                val instance = Room.databaseBuilder(
                    context.applicationContext,
                    CloneVaultDatabase::class.java,
                    "clone_vault_loader.db"
                )
                    .fallbackToDestructiveMigration(dropAllTables = true)
                    .build()
                INSTANCE = instance
                instance
            }
        }
    }
}
