package com.example.data

import android.content.Context
import android.content.Intent
import android.content.pm.ApplicationInfo
import android.content.pm.PackageManager
import android.os.Build
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.withContext

/**
 * UI-safe representation of an installed device application discovered via `PackageManager`.
 * Uses `iconBytes: ByteArray` instead of `Drawable` to preserve strict memory isolation.
 */
data class InstalledAppModel(
    val packageName: String,
    val appName: String,
    val versionName: String,
    val isUserApp: Boolean,
    val iconBytes: ByteArray,
    val iconByteHash: String,
    val iconByteSize: Int
) {
    override fun equals(other: Any?): Boolean {
        if (this === other) return true
        if (other !is InstalledAppModel) return false
        return packageName == other.packageName &&
            appName == other.appName &&
            versionName == other.versionName &&
            isUserApp == other.isUserApp &&
            iconByteHash == other.iconByteHash
    }

    override fun hashCode(): Int {
        var result = packageName.hashCode()
        result = 31 * result + iconByteHash.hashCode()
        return result
    }
}

/**
 * Repository coordinating Room persistence, multi-account profile containers,
 * and `PackageManager` queries with `ByteArray` icon conversion.
 */
class CloneRepository(
    private val context: Context,
    private val dao: CloneVaultDao
) {
    val allProfiles: Flow<List<ProfileContainerEntity>> = dao.observeAllProfiles()
    val allClonedApps: Flow<List<ClonedAppEntity>> = dao.observeAllClonedApps()

    fun observeClonedAppsForProfile(profileId: String): Flow<List<ClonedAppEntity>> {
        return dao.observeClonedAppsForProfile(profileId)
    }

    /**
     * Ensures default account containers ("Account #1", "Account #2", "Account #3") exist
     * and seeds initial cloned apps from real installed packages on first run.
     */
    suspend fun ensureDefaultProfilesAndSeed() = withContext(Dispatchers.IO) {
        if (dao.getProfileCount() > 0) return@withContext

        val now = System.currentTimeMillis()
        val defaultProfiles = listOf(
            ProfileContainerEntity(
                profileId = "account_1",
                displayName = "Account #1",
                environmentTag = "PRIMARY CONTAINER",
                accentColorHex = 0xFF22D3EE,
                createdAt = now
            ),
            ProfileContainerEntity(
                profileId = "account_2",
                displayName = "Account #2",
                environmentTag = "WORK SANDBOX",
                accentColorHex = 0xFF818CF8,
                createdAt = now + 10
            ),
            ProfileContainerEntity(
                profileId = "account_3",
                displayName = "Account #3",
                environmentTag = "STEALTH VAULT",
                accentColorHex = 0xFF10B981,
                createdAt = now + 20
            )
        )
        dao.insertProfiles(defaultProfiles)

        // Discover real installed apps on device to pre-populate Account #1 & Account #2
        val installed = queryInstalledDeviceApps(onlyUserApps = false)
        val seedCandidates = installed.filter { it.packageName != context.packageName }.take(4)

        if (seedCandidates.isNotEmpty()) {
            val account1Clones = seedCandidates.take(3).mapIndexed { index, app ->
                ClonedAppEntity(
                    profileId = "account_1",
                    packageName = app.packageName,
                    appName = app.appName,
                    versionName = app.versionName,
                    isSystemApp = !app.isUserApp,
                    iconBytes = app.iconBytes,
                    iconByteHash = app.iconByteHash,
                    iconByteSize = app.iconByteSize,
                    clonedAt = now + (index * 100L),
                    launchCount = if (index == 0) 3 else 1,
                    lastLaunchedAt = if (index == 0) now - 120_000L else null
                )
            }
            dao.insertClonedApps(account1Clones)

            val account2Clones = seedCandidates.drop(1).take(2).mapIndexed { index, app ->
                ClonedAppEntity(
                    profileId = "account_2",
                    packageName = app.packageName,
                    appName = app.appName,
                    versionName = app.versionName,
                    isSystemApp = !app.isUserApp,
                    iconBytes = app.iconBytes,
                    iconByteHash = app.iconByteHash,
                    iconByteSize = app.iconByteSize,
                    clonedAt = now + 500L + (index * 100L),
                    launchCount = 1,
                    lastLaunchedAt = now - 300_000L
                )
            }
            dao.insertClonedApps(account2Clones)
        }
    }

    /**
     * Queries the device's `PackageManager` to retrieve installed applications,
     * filtering out non-launchable bloatware/system daemons and converting all icons
     * into isolated `ByteArray` buffers.
     */
    suspend fun queryInstalledDeviceApps(onlyUserApps: Boolean): List<InstalledAppModel> =
        withContext(Dispatchers.IO) {
            val pm = context.packageManager
            val selfPkg = context.packageName

            val mainIntent = Intent(Intent.ACTION_MAIN, null).apply {
                addCategory(Intent.CATEGORY_LAUNCHER)
            }
            val resolveInfos = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                pm.queryIntentActivities(
                    mainIntent,
                    PackageManager.ResolveInfoFlags.of(PackageManager.MATCH_ALL.toLong())
                )
            } else {
                @Suppress("DEPRECATION")
                pm.queryIntentActivities(mainIntent, PackageManager.MATCH_ALL)
            }
            val launchablePackages = resolveInfos
                .mapNotNull { it.activityInfo?.packageName }
                .toSet()

            val installedPackages = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                pm.getInstalledApplications(
                    PackageManager.ApplicationInfoFlags.of(PackageManager.GET_META_DATA.toLong())
                )
            } else {
                @Suppress("DEPRECATION")
                pm.getInstalledApplications(PackageManager.GET_META_DATA)
            }

            val result = mutableListOf<InstalledAppModel>()
            val bloatwareKeywords = listOf(
                "provider", "systemui", "overlay", "auto_generated", "bluetooth",
                "nfc", "telecom", "telephony", "keychain", "certinstaller",
                "pacprocessor", "simapp", "traceur", "printspooler", "bips",
                "vpndialogs", "shell", "ext.services", "ext.shared", "cts",
                "webview", "inputmethod", "LatinIME", "permissioncontroller",
                "modulemetadata", "captiveportal", "networkstack", "cellbroadcast"
            )

            val hasThirdPartyApks = installedPackages.any { info ->
                val pkg = info.packageName ?: ""
                pkg != selfPkg &&
                    ((info.flags and ApplicationInfo.FLAG_SYSTEM) == 0 ||
                        (info.flags and ApplicationInfo.FLAG_UPDATED_SYSTEM_APP) != 0) &&
                    launchablePackages.contains(pkg)
            }

            for (appInfo in installedPackages) {
                val pkgName = appInfo.packageName ?: continue
                if (pkgName == selfPkg) continue

                val isBloatwareDaemon = bloatwareKeywords.any { keyword ->
                    pkgName.contains(keyword, ignoreCase = true)
                }
                if (isBloatwareDaemon) continue

                val isSystemFlag = (appInfo.flags and ApplicationInfo.FLAG_SYSTEM) != 0
                val isUpdatedSystemApp = (appInfo.flags and ApplicationInfo.FLAG_UPDATED_SYSTEM_APP) != 0
                val isLaunchable = launchablePackages.contains(pkgName) || pm.getLaunchIntentForPackage(pkgName) != null
                if (!isLaunchable) continue

                val isUserClonableApp = if (hasThirdPartyApks) {
                    !isSystemFlag || isUpdatedSystemApp
                } else {
                    !isSystemFlag || isUpdatedSystemApp || (isLaunchable && !pkgName.startsWith("com.android.internal"))
                }

                if (onlyUserApps && !isUserClonableApp) continue

                val label = try {
                    pm.getApplicationLabel(appInfo).toString().takeIf { it.isNotBlank() } ?: pkgName
                } catch (e: Exception) {
                    pkgName.substringAfterLast('.')
                }

                if (pkgName.startsWith("com.android.internal.") || pkgName.contains(".auto_generated_rro")) {
                    continue
                }

                val versionName = try {
                    val pkgInfo = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                        pm.getPackageInfo(pkgName, PackageManager.PackageInfoFlags.of(0))
                    } else {
                        @Suppress("DEPRECATION")
                        pm.getPackageInfo(pkgName, 0)
                    }
                    pkgInfo.versionName ?: "1.0.0"
                } catch (e: Exception) {
                    "1.0.0"
                }

                val iconBytes = try {
                    val drawable = pm.getApplicationIcon(appInfo)
                    IconByteVault.drawableToByteArray(drawable)
                } catch (e: Exception) {
                    IconByteVault.generateIsolatedBadgeIconBytes(
                        monogram = label.take(2),
                        startColorArgb = 0xFF06B6D4.toInt(),
                        endColorArgb = 0xFF6366F1.toInt()
                    )
                }
                val byteHash = IconByteVault.computeByteSignature(iconBytes)

                result.add(
                    InstalledAppModel(
                        packageName = pkgName,
                        appName = label,
                        versionName = versionName,
                        isUserApp = isUserClonableApp,
                        iconBytes = iconBytes,
                        iconByteHash = byteHash,
                        iconByteSize = iconBytes.size
                    )
                )
            }

            result.sortedWith(
                compareByDescending<InstalledAppModel> { it.isUserApp }
                    .thenBy { it.appName.lowercase() }
            )
        }

    suspend fun createNewProfileContainer(
        displayName: String,
        environmentTag: String
    ): ProfileContainerEntity = withContext(Dispatchers.IO) {
        val count = dao.getProfileCount() + 1
        val palette = listOf(0xFF22D3EE, 0xFF818CF8, 0xFF10B981, 0xFFF59E0B, 0xFFF472B6)
        val profile = ProfileContainerEntity(
            profileId = "account_${System.currentTimeMillis()}",
            displayName = displayName.trim().ifEmpty { "Account #$count" },
            environmentTag = environmentTag.trim().ifEmpty { "ISOLATED SANDBOX" }.uppercase(),
            accentColorHex = palette[count % palette.size]
        )
        dao.insertProfile(profile)
        profile
    }

    suspend fun cloneAppsIntoProfile(
        profileId: String,
        apps: List<InstalledAppModel>
    ) = withContext(Dispatchers.IO) {
        val now = System.currentTimeMillis()
        val entities = apps.mapIndexed { idx, app ->
            ClonedAppEntity(
                profileId = profileId,
                packageName = app.packageName,
                appName = app.appName,
                versionName = app.versionName,
                isSystemApp = !app.isUserApp,
                iconBytes = app.iconBytes,
                iconByteHash = app.iconByteHash,
                iconByteSize = app.iconByteSize,
                clonedAt = now + idx
            )
        }
        dao.insertClonedApps(entities)
    }

    suspend fun removeClonedApp(cloneId: Long) = withContext(Dispatchers.IO) {
        dao.deleteClonedAppById(cloneId)
    }

    suspend fun removeClonedAppByPackage(profileId: String, packageName: String) =
        withContext(Dispatchers.IO) {
            dao.deleteClonedAppByPackage(profileId, packageName)
        }

    suspend fun recordCloneLaunch(cloneId: Long) = withContext(Dispatchers.IO) {
        dao.recordCloneLaunch(cloneId)
    }
}
