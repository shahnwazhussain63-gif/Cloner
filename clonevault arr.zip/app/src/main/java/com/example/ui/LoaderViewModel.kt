package com.example.ui

import android.content.Context
import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope
import com.example.data.CloneRepository
import com.example.data.CloneVaultDatabase
import com.example.data.ClonedAppEntity
import com.example.data.InstalledAppModel
import com.example.data.ProfileContainerEntity
import com.example.sdk.ActivationStatus
import com.example.sdk.MetaActivationManager
import com.example.sdk.SdkEngineState
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

/**
 * Navigation destinations for the separated `ui(src)` App Cloning Loader.
 */
sealed interface LoaderScreen {
    data object Dashboard : LoaderScreen
    data object AppDrawer : LoaderScreen
}

private data class LocalControlState(
    val currentScreen: LoaderScreen = LoaderScreen.Dashboard,
    val selectedProfileId: String = "account_1",
    val installedApps: List<InstalledAppModel> = emptyList(),
    val isLoadingInstalledApps: Boolean = false,
    val onlyUserAppsFilter: Boolean = true,
    val drawerSearchQuery: String = "",
    val selectedPackagesForCloning: Set<String> = emptySet(),
    val showSdkDialog: Boolean = false,
    val showCreateProfileDialog: Boolean = false,
    val inspectingClone: ClonedAppEntity? = null,
    val statusBannerMessage: String? = null,
    val aarBinaryReport: AarBinaryReport = AarBinaryReport()
)

data class LoaderUiState(
    val currentScreen: LoaderScreen = LoaderScreen.Dashboard,
    val profiles: List<ProfileContainerEntity> = emptyList(),
    val activeProfile: ProfileContainerEntity = ProfileContainerEntity(
        profileId = "account_1",
        displayName = "Account #1",
        environmentTag = "PRIMARY CONTAINER",
        accentColorHex = 0xFF22D3EE
    ),
    val clonedAppsInActiveProfile: List<ClonedAppEntity> = emptyList(),
    val cloneCountsByProfile: Map<String, Int> = emptyMap(),
    val totalIsolatedBytesInProfile: Int = 0,
    val installedApps: List<InstalledAppModel> = emptyList(),
    val clonedPackagesInActiveProfile: Set<String> = emptySet(),
    val isLoadingInstalledApps: Boolean = false,
    val onlyUserAppsFilter: Boolean = true,
    val drawerSearchQuery: String = "",
    val selectedPackagesForCloning: Set<String> = emptySet(),
    val sdkEngineState: SdkEngineState = SdkEngineState(),
    val aarBinaryReport: AarBinaryReport = AarBinaryReport(),
    val showSdkDialog: Boolean = false,
    val showCreateProfileDialog: Boolean = false,
    val inspectingClone: ClonedAppEntity? = null,
    val statusBannerMessage: String? = null
)

/**
 * Separated `ui(src)` ViewModel consuming `com.example.sdk.MetaActivationManager`
 * directly from `app/libs/meta-activation-sdk.aar`.
 */
class LoaderViewModel(
    private val appContext: Context,
    private val repository: CloneRepository
) : ViewModel() {

    private val controlState = MutableStateFlow(LocalControlState())

    val uiState: StateFlow<LoaderUiState> = combine(
        repository.allProfiles,
        repository.allClonedApps,
        MetaActivationManager.engineState,
        controlState
    ) { profiles, allClones, sdkState, local ->
        val fallbackProfile = ProfileContainerEntity(
            profileId = "account_1",
            displayName = "Account #1",
            environmentTag = "PRIMARY CONTAINER",
            accentColorHex = 0xFF22D3EE
        )
        val activeProfile = profiles.find { it.profileId == local.selectedProfileId }
            ?: profiles.firstOrNull()
            ?: fallbackProfile

        val clonesInProfile = allClones
            .filter { it.profileId == activeProfile.profileId }
            .sortedBy { it.appName.lowercase() }

        val countsByProfile = allClones.groupingBy { it.profileId }.eachCount()
        val totalBytes = clonesInProfile.sumOf { it.iconByteSize }
        val clonedPackagesSet = clonesInProfile.map { it.packageName }.toSet()

        val filteredInstalled = local.installedApps.filter { app ->
            val matchesFilter = if (local.onlyUserAppsFilter) app.isUserApp else true
            val q = local.drawerSearchQuery.trim()
            val matchesSearch = q.isEmpty() ||
                app.appName.contains(q, ignoreCase = true) ||
                app.packageName.contains(q, ignoreCase = true)
            matchesFilter && matchesSearch
        }

        LoaderUiState(
            currentScreen = local.currentScreen,
            profiles = profiles.ifEmpty { listOf(fallbackProfile) },
            activeProfile = activeProfile,
            clonedAppsInActiveProfile = clonesInProfile,
            cloneCountsByProfile = countsByProfile,
            totalIsolatedBytesInProfile = totalBytes,
            installedApps = filteredInstalled,
            clonedPackagesInActiveProfile = clonedPackagesSet,
            isLoadingInstalledApps = local.isLoadingInstalledApps,
            onlyUserAppsFilter = local.onlyUserAppsFilter,
            drawerSearchQuery = local.drawerSearchQuery,
            selectedPackagesForCloning = local.selectedPackagesForCloning,
            sdkEngineState = sdkState,
            aarBinaryReport = local.aarBinaryReport,
            showSdkDialog = local.showSdkDialog,
            showCreateProfileDialog = local.showCreateProfileDialog,
            inspectingClone = local.inspectingClone,
            statusBannerMessage = local.statusBannerMessage
        )
    }.stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(5000),
        initialValue = LoaderUiState()
    )

    init {
        viewModelScope.launch {
            val report = withContext(Dispatchers.IO) {
                AarBinaryInspector.inspectCompiledAar(appContext)
            }
            controlState.update { it.copy(aarBinaryReport = report) }
            repository.ensureDefaultProfilesAndSeed()
            refreshInstalledApps()
        }
    }

    fun refreshInstalledApps() {
        viewModelScope.launch {
            controlState.update { it.copy(isLoadingInstalledApps = true) }
            val apps = repository.queryInstalledDeviceApps(onlyUserApps = false)
            controlState.update {
                it.copy(
                    installedApps = apps,
                    isLoadingInstalledApps = false
                )
            }
        }
    }

    fun switchProfile(profileId: String) {
        val targetName = uiState.value.profiles.find { it.profileId == profileId }?.displayName ?: "Container"
        controlState.update {
            it.copy(
                selectedProfileId = profileId,
                selectedPackagesForCloning = emptySet(),
                statusBannerMessage = "Switched isolated namespace to $targetName"
            )
        }
    }

    fun createNewProfile(displayName: String, environmentTag: String) {
        viewModelScope.launch {
            val created = repository.createNewProfileContainer(displayName, environmentTag)
            controlState.update {
                it.copy(
                    selectedProfileId = created.profileId,
                    showCreateProfileDialog = false,
                    statusBannerMessage = "Provisioned container ${created.displayName}"
                )
            }
        }
    }

    fun openAppDrawer() {
        controlState.update {
            it.copy(
                currentScreen = LoaderScreen.AppDrawer,
                selectedPackagesForCloning = emptySet(),
                drawerSearchQuery = ""
            )
        }
        if (controlState.value.installedApps.isEmpty()) {
            refreshInstalledApps()
        }
    }

    fun navigateBackToDashboard() {
        controlState.update {
            it.copy(
                currentScreen = LoaderScreen.Dashboard,
                selectedPackagesForCloning = emptySet(),
                drawerSearchQuery = ""
            )
        }
    }

    fun setDrawerSearchQuery(query: String) {
        controlState.update { it.copy(drawerSearchQuery = query) }
    }

    fun setOnlyUserAppsFilter(onlyUser: Boolean) {
        controlState.update { it.copy(onlyUserAppsFilter = onlyUser) }
    }

    fun togglePackageSelection(packageName: String) {
        controlState.update { state ->
            val updated = state.selectedPackagesForCloning.toMutableSet()
            if (updated.contains(packageName)) {
                updated.remove(packageName)
            } else {
                updated.add(packageName)
            }
            state.copy(selectedPackagesForCloning = updated)
        }
    }

    fun selectAllUnclonedVisibleApps() {
        val currentUi = uiState.value
        val eligible = currentUi.installedApps
            .map { it.packageName }
            .filter { !currentUi.clonedPackagesInActiveProfile.contains(it) }
            .toSet()
        controlState.update { it.copy(selectedPackagesForCloning = eligible) }
    }

    fun clearSelection() {
        controlState.update { it.copy(selectedPackagesForCloning = emptySet()) }
    }

    fun cloneSingleApp(app: InstalledAppModel) {
        val activeProfile = uiState.value.activeProfile
        viewModelScope.launch {
            repository.cloneAppsIntoProfile(activeProfile.profileId, listOf(app))
            controlState.update {
                it.copy(
                    statusBannerMessage = "Cloned ${app.appName} (${app.iconByteHash}) into ${activeProfile.displayName}"
                )
            }
        }
    }

    fun cloneSelectedAppsAndReturn() {
        val currentUi = uiState.value
        val selectedSet = currentUi.selectedPackagesForCloning
        if (selectedSet.isEmpty()) return

        val appsToClone = controlState.value.installedApps.filter { selectedSet.contains(it.packageName) }
        if (appsToClone.isEmpty()) return

        viewModelScope.launch {
            repository.cloneAppsIntoProfile(currentUi.activeProfile.profileId, appsToClone)
            controlState.update {
                it.copy(
                    currentScreen = LoaderScreen.Dashboard,
                    selectedPackagesForCloning = emptySet(),
                    drawerSearchQuery = "",
                    statusBannerMessage = "Cloned ${appsToClone.size} app(s) into ${currentUi.activeProfile.displayName} with ByteArray isolation"
                )
            }
        }
    }

    fun removeClonedApp(clone: ClonedAppEntity) {
        viewModelScope.launch {
            repository.removeClonedApp(clone.id)
            controlState.update {
                it.copy(
                    inspectingClone = null,
                    statusBannerMessage = "Removed ${clone.appName} from ${uiState.value.activeProfile.displayName}"
                )
            }
        }
    }

    /**
     * Invokes `MetaActivationManager` from the compiled `meta-activation-sdk.aar` library:
     * 1. Queries `MetaActivationManager.getActivationStatus()`
     * 2. If not active, opens the SDK activation modal so the user can call `activateSdk(key)`.
     * 3. If active, invokes `MetaActivationManager.launchApp(packageName)` and records the launch in Room.
     */
    fun launchClonedApp(clone: ClonedAppEntity) {
        val status = MetaActivationManager.getActivationStatus()
        if (status != ActivationStatus.ACTIVE) {
            controlState.update {
                it.copy(
                    showSdkDialog = true,
                    statusBannerMessage = "meta-activation-sdk.aar activation required before launching ${clone.appName}"
                )
            }
            return
        }

        val activeProfile = uiState.value.activeProfile
        val session = MetaActivationManager.launchApp(
            packageName = clone.packageName,
            profileId = activeProfile.profileId,
            profileName = activeProfile.displayName,
            appName = clone.appName,
            iconByteHash = clone.iconByteHash,
            iconByteSize = clone.iconByteSize
        )
        if (session != null) {
            viewModelScope.launch {
                repository.recordCloneLaunch(clone.id)
            }
        }
    }

    fun activateSdk(key: String): Boolean {
        val success = MetaActivationManager.activateSdk(key)
        controlState.update {
            it.copy(
                statusBannerMessage = if (success) {
                    "meta-activation-sdk.aar: SDK activated with key ${key.trim().uppercase()}"
                } else {
                    "meta-activation-sdk.aar: License key rejected by .aar verifier"
                }
            )
        }
        return success
    }

    fun deactivateSdkForTesting() {
        MetaActivationManager.deactivateSdkForTesting()
        controlState.update {
            it.copy(statusBannerMessage = "SDK placed in UNLICENSED mode for testing")
        }
    }

    fun dismissActiveLaunchSession() {
        MetaActivationManager.dismissActiveSession()
    }

    fun setShowSdkDialog(show: Boolean) {
        controlState.update { it.copy(showSdkDialog = show) }
    }

    fun setShowCreateProfileDialog(show: Boolean) {
        controlState.update { it.copy(showCreateProfileDialog = show) }
    }

    fun setInspectingClone(clone: ClonedAppEntity?) {
        controlState.update { it.copy(inspectingClone = clone) }
    }

    fun clearStatusBanner() {
        controlState.update { it.copy(statusBannerMessage = null) }
    }

    class Factory(private val appContext: Context) : ViewModelProvider.Factory {
        @Suppress("UNCHECKED_CAST")
        override fun <T : ViewModel> create(modelClass: Class<T>): T {
            val database = CloneVaultDatabase.getInstance(appContext)
            val repository = CloneRepository(appContext, database.cloneVaultDao())
            return LoaderViewModel(appContext, repository) as T
        }
    }
}
