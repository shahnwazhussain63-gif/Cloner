package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Deep Obsidian & Slate Surfaces
val ObsidianBackground = Color(0xFF0B1120)
val ObsidianSurface = Color(0xFF111827)
val ObsidianSurfaceVariant = Color(0xFF1E293B)
val ObsidianCard = Color(0xFF162032)
val ObsidianOutline = Color(0xFF334155)

// Electric Cyan & Indigo Accents
val ElectricCyan = Color(0xFF06B6D4)
val ElectricCyanBright = Color(0xFF22D3EE)
val ElectricCyanContainer = Color(0xFF083344)
val OnElectricCyanContainer = Color(0xFFCFFAFE)

val RoyalIndigo = Color(0xFF6366F1)
val RoyalIndigoLight = Color(0xFF818CF8)
val RoyalIndigoContainer = Color(0xFF1E1B4B)
val OnRoyalIndigoContainer = Color(0xFFE0E7FF)

// Status & Telemetry Accents
val EmeraldActive = Color(0xFF10B981)
val EmeraldContainer = Color(0xFF064E3B)
val AmberWarning = Color(0xFFF59E0B)
val AmberContainer = Color(0xFF451A03)
val CrimsonError = Color(0xFFEF4444)

// Light mode counterparts for adaptive support
val LightBackground = Color(0xFFF8FAFC)
val LightSurface = Color(0xFFFFFFFF)
val LightSurfaceVariant = Color(0xFFE2E8F0)
val LightPrimary = Color(0xFF0284C7)
val LightSecondary = Color(0xFF4F46E5)
