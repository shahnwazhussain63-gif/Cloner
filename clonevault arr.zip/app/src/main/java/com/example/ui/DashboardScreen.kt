package com.example.ui

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.safeDrawing
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.GridItemSpan
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Apps
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.CreateNewFolder
import androidx.compose.material.icons.filled.FolderZip
import androidx.compose.material.icons.filled.KeyboardArrowDown
import androidx.compose.material.icons.filled.Layers
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.Memory
import androidx.compose.material.icons.filled.MoreVert
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Shield
import androidx.compose.material.icons.filled.VerifiedUser
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.ExtendedFloatingActionButton
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.example.R
import com.example.data.ClonedAppEntity
import com.example.data.IconByteVault
import com.example.data.ProfileContainerEntity
import com.example.sdk.ActivationStatus
import com.example.sdk.SdkEngineState
import com.example.ui.theme.AmberWarning
import com.example.ui.theme.CrimsonError
import com.example.ui.theme.ElectricCyan
import com.example.ui.theme.ElectricCyanBright
import com.example.ui.theme.EmeraldActive
import com.example.ui.theme.ObsidianCard
import com.example.ui.theme.RoyalIndigo

@Composable
fun DashboardScreen(
    uiState: LoaderUiState,
    onSwitchProfile: (String) -> Unit,
    onOpenNewProfileDialog: () -> Unit,
    onOpenAppDrawer: () -> Unit,
    onLaunchClone: (ClonedAppEntity) -> Unit,
    onInspectClone: (ClonedAppEntity) -> Unit,
    onOpenSdkDialog: () -> Unit,
    onDismissBanner: () -> Unit,
    modifier: Modifier = Modifier
) {
    val activeProfile = uiState.activeProfile
    val profileIndexBadge = remember(activeProfile.displayName, uiState.profiles) {
        val idx = uiState.profiles.indexOfFirst { it.profileId == activeProfile.profileId }
        if (idx >= 0) "#${idx + 1}" else "#1"
    }

    Scaffold(
        modifier = modifier.fillMaxSize(),
        contentWindowInsets = WindowInsets.safeDrawing,
        topBar = {
            CloneLoaderTopAppBar(
                activeProfile = activeProfile,
                profiles = uiState.profiles,
                cloneCountsByProfile = uiState.cloneCountsByProfile,
                sdkState = uiState.sdkEngineState,
                onSelectProfile = onSwitchProfile,
                onAddNewProfile = onOpenNewProfileDialog,
                onOpenSdkDialog = onOpenSdkDialog
            )
        },
        floatingActionButton = {
            ExtendedFloatingActionButton(
                onClick = onOpenAppDrawer,
                containerColor = ElectricCyanBright,
                contentColor = Color(0xFF042F2E),
                icon = {
                    Icon(
                        imageVector = Icons.Default.Add,
                        contentDescription = "Clone New Application"
                    )
                },
                text = {
                    Text(
                        text = "Clone App",
                        fontWeight = FontWeight.ExtraBold
                    )
                },
                modifier = Modifier.testTag("open_app_drawer_fab")
            )
        }
    ) { innerPadding ->
        LazyVerticalGrid(
            columns = GridCells.Adaptive(minSize = 112.dp),
            contentPadding = PaddingValues(
                start = 16.dp,
                end = 16.dp,
                top = innerPadding.calculateTopPadding() + 8.dp,
                bottom = innerPadding.calculateBottomPadding() + 92.dp
            ),
            horizontalArrangement = Arrangement.spacedBy(12.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp),
            modifier = Modifier
                .fillMaxSize()
                .testTag("cloned_apps_grid")
        ) {
            if (uiState.statusBannerMessage != null) {
                item(span = { GridItemSpan(maxLineSpan) }) {
                    AnimatedVisibility(
                        visible = true,
                        enter = fadeIn(),
                        exit = fadeOut()
                    ) {
                        StatusFeedbackBanner(
                            message = uiState.statusBannerMessage,
                            onDismiss = onDismissBanner
                        )
                    }
                }
            }

            // Hero Container Telemetry Header + 2-Part (.aar SDK + ui(src)) Strip
            item(span = { GridItemSpan(maxLineSpan) }) {
                ContainerHeroBanner(
                    activeProfile = activeProfile,
                    profiles = uiState.profiles,
                    clonedCount = uiState.clonedAppsInActiveProfile.size,
                    totalIsolatedBytes = uiState.totalIsolatedBytesInProfile,
                    sdkState = uiState.sdkEngineState,
                    aarReport = uiState.aarBinaryReport,
                    onSelectProfile = onSwitchProfile,
                    onOpenSdkDialog = onOpenSdkDialog
                )
            }

            // Section Header
            item(span = { GridItemSpan(maxLineSpan) }) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween,
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(top = 4.dp, bottom = 2.dp)
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(
                            imageVector = Icons.Default.Apps,
                            contentDescription = null,
                            tint = ElectricCyanBright,
                            modifier = Modifier.size(18.dp)
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = "${activeProfile.displayName} Clones",
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.Bold
                        )
                    }

                    Surface(
                        shape = RoundedCornerShape(50),
                        color = MaterialTheme.colorScheme.surfaceVariant
                    ) {
                        Text(
                            text = "${uiState.clonedAppsInActiveProfile.size} Isolated • ByteArray Vault",
                            style = MaterialTheme.typography.labelSmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                            modifier = Modifier.padding(horizontal = 10.dp, vertical = 4.dp)
                        )
                    }
                }
            }

            if (uiState.clonedAppsInActiveProfile.isEmpty()) {
                item(span = { GridItemSpan(maxLineSpan) }) {
                    EmptyContainerStateCard(
                        profileName = activeProfile.displayName,
                        onOpenAppDrawer = onOpenAppDrawer
                    )
                }
            } else {
                items(
                    items = uiState.clonedAppsInActiveProfile,
                    key = { "${it.profileId}_${it.packageName}" }
                ) { clone ->
                    ClonedAppGridCard(
                        clone = clone,
                        profileBadge = profileIndexBadge,
                        profileAccent = Color(activeProfile.accentColorHex),
                        onLaunch = { onLaunchClone(clone) },
                        onInspect = { onInspectClone(clone) }
                    )
                }
            }
        }
    }
}

@Composable
private fun CloneLoaderTopAppBar(
    activeProfile: ProfileContainerEntity,
    profiles: List<ProfileContainerEntity>,
    cloneCountsByProfile: Map<String, Int>,
    sdkState: SdkEngineState,
    onSelectProfile: (String) -> Unit,
    onAddNewProfile: () -> Unit,
    onOpenSdkDialog: () -> Unit
) {
    var profileMenuExpanded by remember { mutableStateOf(false) }
    val profileAccent = Color(activeProfile.accentColorHex)

    Surface(
        color = MaterialTheme.colorScheme.background.copy(alpha = 0.96f),
        tonalElevation = 4.dp,
        modifier = Modifier.fillMaxWidth()
    ) {
        Row(
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween,
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 16.dp, vertical = 12.dp)
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                modifier = Modifier.weight(1f)
            ) {
                Box(
                    contentAlignment = Alignment.Center,
                    modifier = Modifier
                        .size(40.dp)
                        .clip(RoundedCornerShape(12.dp))
                        .background(
                            Brush.linearGradient(
                                listOf(ElectricCyan, RoyalIndigo)
                            )
                        )
                ) {
                    Icon(
                        imageVector = Icons.Default.Layers,
                        contentDescription = "CloneVault Loader",
                        tint = Color.White,
                        modifier = Modifier.size(22.dp)
                    )
                }

                Spacer(modifier = Modifier.width(10.dp))

                Box {
                    Surface(
                        shape = RoundedCornerShape(14.dp),
                        color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.85f),
                        modifier = Modifier
                            .clip(RoundedCornerShape(14.dp))
                            .border(
                                width = 1.dp,
                                color = profileAccent.copy(alpha = 0.55f),
                                shape = RoundedCornerShape(14.dp)
                            )
                            .clickable { profileMenuExpanded = true }
                            .testTag("profile_switcher_dropdown_button")
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            modifier = Modifier.padding(horizontal = 12.dp, vertical = 7.dp)
                        ) {
                            Box(
                                modifier = Modifier
                                    .size(9.dp)
                                    .clip(CircleShape)
                                    .background(profileAccent)
                            )
                            Spacer(modifier = Modifier.width(8.dp))
                            Column {
                                Text(
                                    text = activeProfile.displayName,
                                    style = MaterialTheme.typography.titleSmall,
                                    fontWeight = FontWeight.Bold,
                                    maxLines = 1,
                                    overflow = TextOverflow.Ellipsis
                                )
                                Text(
                                    text = activeProfile.environmentTag,
                                    style = MaterialTheme.typography.labelSmall,
                                    color = profileAccent,
                                    maxLines = 1
                                )
                            }
                            Spacer(modifier = Modifier.width(6.dp))
                            Icon(
                                imageVector = Icons.Default.KeyboardArrowDown,
                                contentDescription = "Switch Profile Container",
                                tint = MaterialTheme.colorScheme.onSurfaceVariant,
                                modifier = Modifier.size(20.dp)
                            )
                        }
                    }

                    DropdownMenu(
                        expanded = profileMenuExpanded,
                        onDismissRequest = { profileMenuExpanded = false },
                        modifier = Modifier
                            .width(260.dp)
                            .background(MaterialTheme.colorScheme.surface)
                            .border(
                                1.dp,
                                MaterialTheme.colorScheme.outline.copy(alpha = 0.5f),
                                RoundedCornerShape(12.dp)
                            )
                    ) {
                        Text(
                            text = "ACCOUNT CONTAINERS",
                            style = MaterialTheme.typography.labelSmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                            modifier = Modifier.padding(horizontal = 14.dp, vertical = 6.dp)
                        )

                        profiles.forEach { profile ->
                            val isSelected = profile.profileId == activeProfile.profileId
                            val count = cloneCountsByProfile[profile.profileId] ?: 0
                            val dotColor = Color(profile.accentColorHex)

                            DropdownMenuItem(
                                text = {
                                    Column {
                                        Text(
                                            text = profile.displayName,
                                            style = MaterialTheme.typography.bodyLarge,
                                            fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal
                                        )
                                        Text(
                                            text = "${profile.environmentTag} • $count app(s)",
                                            style = MaterialTheme.typography.labelSmall,
                                            color = MaterialTheme.colorScheme.onSurfaceVariant
                                        )
                                    }
                                },
                                leadingIcon = {
                                    Box(
                                        modifier = Modifier
                                            .size(10.dp)
                                            .clip(CircleShape)
                                            .background(dotColor)
                                    )
                                },
                                trailingIcon = {
                                    if (isSelected) {
                                        Icon(
                                            imageVector = Icons.Default.Check,
                                            contentDescription = "Active Profile",
                                            tint = ElectricCyanBright,
                                            modifier = Modifier.size(18.dp)
                                        )
                                    }
                                },
                                onClick = {
                                    profileMenuExpanded = false
                                    onSelectProfile(profile.profileId)
                                },
                                modifier = Modifier.testTag("dropdown_profile_${profile.profileId}")
                            )
                        }

                        HorizontalDivider(
                            modifier = Modifier.padding(vertical = 4.dp),
                            color = MaterialTheme.colorScheme.outline.copy(alpha = 0.3f)
                        )

                        DropdownMenuItem(
                            text = {
                                Text(
                                    text = "Create Account Container…",
                                    style = MaterialTheme.typography.labelLarge,
                                    color = ElectricCyanBright
                                )
                            },
                            leadingIcon = {
                                Icon(
                                    imageVector = Icons.Default.CreateNewFolder,
                                    contentDescription = null,
                                    tint = ElectricCyanBright
                                )
                            },
                            onClick = {
                                profileMenuExpanded = false
                                onAddNewProfile()
                            },
                            modifier = Modifier.testTag("dropdown_create_profile_item")
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.width(8.dp))

            val isSdkActive = sdkState.status == ActivationStatus.ACTIVE
            val badgeTint = when (sdkState.status) {
                ActivationStatus.ACTIVE -> EmeraldActive
                ActivationStatus.UNLICENSED -> AmberWarning
                ActivationStatus.INVALID_KEY -> CrimsonError
            }

            Surface(
                shape = RoundedCornerShape(12.dp),
                color = badgeTint.copy(alpha = 0.14f),
                modifier = Modifier
                    .clip(RoundedCornerShape(12.dp))
                    .border(
                        1.dp,
                        badgeTint.copy(alpha = 0.45f),
                        RoundedCornerShape(12.dp)
                    )
                    .clickable(onClick = onOpenSdkDialog)
                    .testTag("sdk_status_topbar_button")
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    modifier = Modifier.padding(horizontal = 10.dp, vertical = 8.dp)
                ) {
                    Icon(
                        imageVector = if (isSdkActive) Icons.Default.VerifiedUser else Icons.Default.Lock,
                        contentDescription = "SDK Activation Status",
                        tint = badgeTint,
                        modifier = Modifier.size(16.dp)
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(
                        text = if (isSdkActive) "SDK .AAR ACTIVE" else "ACTIVATE .AAR",
                        style = MaterialTheme.typography.labelSmall,
                        color = badgeTint,
                        fontWeight = FontWeight.ExtraBold
                    )
                }
            }
        }
    }
}

@Composable
private fun ContainerHeroBanner(
    activeProfile: ProfileContainerEntity,
    profiles: List<ProfileContainerEntity>,
    clonedCount: Int,
    totalIsolatedBytes: Int,
    sdkState: SdkEngineState,
    aarReport: AarBinaryReport,
    onSelectProfile: (String) -> Unit,
    onOpenSdkDialog: () -> Unit
) {
    val accentColor = Color(activeProfile.accentColorHex)

    Card(
        shape = RoundedCornerShape(22.dp),
        colors = CardDefaults.cardColors(containerColor = ObsidianCard),
        elevation = CardDefaults.cardElevation(defaultElevation = 4.dp),
        modifier = Modifier
            .fillMaxWidth()
            .border(
                width = 1.dp,
                color = accentColor.copy(alpha = 0.38f),
                shape = RoundedCornerShape(22.dp)
            )
    ) {
        Box(modifier = Modifier.fillMaxWidth()) {
            Image(
                painter = painterResource(id = R.drawable.img_container_hero),
                contentDescription = null,
                contentScale = ContentScale.Crop,
                alpha = 0.38f,
                modifier = Modifier.matchParentSize()
            )

            Box(
                modifier = Modifier
                    .matchParentSize()
                    .background(
                        Brush.verticalGradient(
                            colors = listOf(
                                Color(0xCC0B1120),
                                Color(0xF50B1120)
                            )
                        )
                    )
            )

            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(16.dp)
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween,
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(
                                imageVector = Icons.Default.Shield,
                                contentDescription = null,
                                tint = accentColor,
                                modifier = Modifier.size(16.dp)
                            )
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(
                                text = "ACTIVE SANDBOX SESSION • ${activeProfile.environmentTag}",
                                style = MaterialTheme.typography.labelSmall,
                                color = accentColor,
                                fontWeight = FontWeight.Bold
                            )
                        }
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(
                            text = activeProfile.displayName,
                            style = MaterialTheme.typography.headlineMedium,
                            color = Color.White
                        )
                    }

                    Surface(
                        shape = RoundedCornerShape(10.dp),
                        color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.85f),
                        modifier = Modifier
                            .clip(RoundedCornerShape(10.dp))
                            .clickable(onClick = onOpenSdkDialog)
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp)
                        ) {
                            Icon(
                                imageVector = Icons.Default.Memory,
                                contentDescription = null,
                                tint = ElectricCyanBright,
                                modifier = Modifier.size(15.dp)
                            )
                            Spacer(modifier = Modifier.width(5.dp))
                            Text(
                                text = "meta-activation-sdk.aar",
                                style = MaterialTheme.typography.labelSmall,
                                color = Color.White
                            )
                        }
                    }
                }

                Spacer(modifier = Modifier.height(10.dp))

                // 2-Part Split Architecture Pill (Part 1: SDK .aar | Part 2: ui(src))
                Surface(
                    shape = RoundedCornerShape(12.dp),
                    color = Color(0xFF070B14).copy(alpha = 0.9f),
                    modifier = Modifier
                        .fillMaxWidth()
                        .border(
                            1.dp,
                            ElectricCyan.copy(alpha = 0.32f),
                            RoundedCornerShape(12.dp)
                        )
                        .clickable(onClick = onOpenSdkDialog)
                        .testTag("sdk_architecture_banner")
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween,
                        modifier = Modifier.padding(horizontal = 12.dp, vertical = 8.dp)
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            modifier = Modifier.weight(1f)
                        ) {
                            Icon(
                                imageVector = Icons.Default.FolderZip,
                                contentDescription = null,
                                tint = ElectricCyanBright,
                                modifier = Modifier.size(16.dp)
                            )
                            Spacer(modifier = Modifier.width(8.dp))
                            Column {
                                Text(
                                    text = "Part 1 SDK: libs/${aarReport.fileName} (${aarReport.sha256Hex})",
                                    style = MaterialTheme.typography.labelSmall,
                                    color = ElectricCyanBright,
                                    fontWeight = FontWeight.Bold
                                )
                                Text(
                                    text = "Part 2 Consumer: com.example.ui (src) -> MetaActivationManager",
                                    style = MaterialTheme.typography.labelSmall,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            }
                        }
                        Text(
                            text = "INSPECT",
                            style = MaterialTheme.typography.labelSmall,
                            color = EmeraldActive,
                            fontWeight = FontWeight.ExtraBold
                        )
                    }
                }

                Spacer(modifier = Modifier.height(12.dp))

                LazyRow(
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    items(profiles, key = { it.profileId }) { profile ->
                        val isSelected = profile.profileId == activeProfile.profileId
                        val chipAccent = Color(profile.accentColorHex)

                        Surface(
                            shape = RoundedCornerShape(50),
                            color = if (isSelected) {
                                chipAccent.copy(alpha = 0.24f)
                            } else {
                                Color.White.copy(alpha = 0.06f)
                            },
                            modifier = Modifier
                                .clip(RoundedCornerShape(50))
                                .border(
                                    width = 1.dp,
                                    color = if (isSelected) chipAccent else Color.White.copy(alpha = 0.12f),
                                    shape = RoundedCornerShape(50)
                                )
                                .clickable { onSelectProfile(profile.profileId) }
                                .testTag("quick_profile_pill_${profile.profileId}")
                        ) {
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                modifier = Modifier.padding(horizontal = 12.dp, vertical = 6.dp)
                            ) {
                                Box(
                                    modifier = Modifier
                                        .size(7.dp)
                                        .clip(CircleShape)
                                        .background(chipAccent)
                                )
                                Spacer(modifier = Modifier.width(6.dp))
                                Text(
                                    text = profile.displayName,
                                    style = MaterialTheme.typography.labelLarge,
                                    color = if (isSelected) Color.White else MaterialTheme.colorScheme.onSurfaceVariant,
                                    fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Medium
                                )
                            }
                        }
                    }
                }

                Spacer(modifier = Modifier.height(14.dp))

                Row(
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    HeroMetricPill(
                        label = "CLONED APPS",
                        value = "$clonedCount Instances",
                        accent = accentColor,
                        modifier = Modifier.weight(1f)
                    )
                    HeroMetricPill(
                        label = "ICON SEGREGATION",
                        value = IconByteVault.formatByteSize(totalIsolatedBytes),
                        accent = ElectricCyanBright,
                        modifier = Modifier.weight(1f)
                    )
                    HeroMetricPill(
                        label = ".AAR LAUNCHES",
                        value = "${sdkState.totalLaunchesInSession} Calls",
                        accent = EmeraldActive,
                        modifier = Modifier.weight(1f)
                    )
                }
            }
        }
    }
}

@Composable
private fun HeroMetricPill(
    label: String,
    value: String,
    accent: Color,
    modifier: Modifier = Modifier
) {
    Surface(
        shape = RoundedCornerShape(12.dp),
        color = Color(0xFF0A101D).copy(alpha = 0.85f),
        modifier = modifier.border(
            width = 1.dp,
            color = Color.White.copy(alpha = 0.08f),
            shape = RoundedCornerShape(12.dp)
        )
    ) {
        Column(modifier = Modifier.padding(horizontal = 10.dp, vertical = 8.dp)) {
            Text(
                text = label,
                style = MaterialTheme.typography.labelSmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )
            Spacer(modifier = Modifier.height(2.dp))
            Text(
                text = value,
                style = MaterialTheme.typography.labelLarge,
                color = accent,
                fontWeight = FontWeight.Bold,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )
        }
    }
}

@Composable
private fun ClonedAppGridCard(
    clone: ClonedAppEntity,
    profileBadge: String,
    profileAccent: Color,
    onLaunch: () -> Unit,
    onInspect: () -> Unit
) {
    Card(
        shape = RoundedCornerShape(20.dp),
        colors = CardDefaults.cardColors(
            containerColor = ObsidianCard
        ),
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(20.dp))
            .border(
                width = 1.dp,
                color = MaterialTheme.colorScheme.outline.copy(alpha = 0.45f),
                shape = RoundedCornerShape(20.dp)
            )
            .clickable(onClick = onLaunch)
            .testTag("cloned_app_card_${clone.packageName}")
    ) {
        Box(modifier = Modifier.fillMaxWidth()) {
            IconButton(
                onClick = onInspect,
                modifier = Modifier
                    .align(Alignment.TopEnd)
                    .size(36.dp)
                    .testTag("inspect_clone_${clone.packageName}")
            ) {
                Icon(
                    imageVector = Icons.Default.MoreVert,
                    contentDescription = "Inspect or Remove ${clone.appName}",
                    tint = MaterialTheme.colorScheme.onSurfaceVariant,
                    modifier = Modifier.size(16.dp)
                )
            }

            Column(
                horizontalAlignment = Alignment.CenterHorizontally,
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 10.dp, vertical = 14.dp)
            ) {
                ByteArrayAppIcon(
                    iconBytes = clone.iconBytes,
                    iconByteHash = clone.iconByteHash,
                    appName = clone.appName,
                    size = 58.dp,
                    badgeText = profileBadge,
                    badgeColor = profileAccent
                )

                Spacer(modifier = Modifier.height(10.dp))

                Text(
                    text = clone.appName,
                    style = MaterialTheme.typography.titleSmall,
                    color = MaterialTheme.colorScheme.onSurface,
                    fontWeight = FontWeight.Bold,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis,
                    textAlign = TextAlign.Center
                )

                Text(
                    text = clone.packageName,
                    style = MaterialTheme.typography.labelSmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis,
                    textAlign = TextAlign.Center,
                    modifier = Modifier.padding(top = 2.dp)
                )

                Spacer(modifier = Modifier.height(8.dp))

                Surface(
                    shape = RoundedCornerShape(8.dp),
                    color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.65f)
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        modifier = Modifier.padding(horizontal = 7.dp, vertical = 3.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Default.PlayArrow,
                            contentDescription = null,
                            tint = ElectricCyanBright,
                            modifier = Modifier.size(12.dp)
                        )
                        Spacer(modifier = Modifier.width(3.dp))
                        Text(
                            text = clone.iconByteHash,
                            style = MaterialTheme.typography.labelSmall.copy(
                                fontFamily = FontFamily.Monospace
                            ),
                            color = ElectricCyanBright,
                            maxLines = 1
                        )
                    }
                }
            }
        }
    }
}

@Composable
private fun EmptyContainerStateCard(
    profileName: String,
    onOpenAppDrawer: () -> Unit
) {
    Surface(
        shape = RoundedCornerShape(22.dp),
        color = ObsidianCard,
        modifier = Modifier
            .fillMaxWidth()
            .border(
                width = 1.dp,
                color = MaterialTheme.colorScheme.outline.copy(alpha = 0.4f),
                shape = RoundedCornerShape(22.dp)
            )
            .padding(24.dp)
    ) {
        Column(
            horizontalAlignment = Alignment.CenterHorizontally,
            modifier = Modifier.fillMaxWidth()
        ) {
            Box(
                contentAlignment = Alignment.Center,
                modifier = Modifier
                    .size(64.dp)
                    .clip(CircleShape)
                    .background(ElectricCyan.copy(alpha = 0.14f))
            ) {
                Icon(
                    imageVector = Icons.Default.Layers,
                    contentDescription = null,
                    tint = ElectricCyanBright,
                    modifier = Modifier.size(32.dp)
                )
            }
            Spacer(modifier = Modifier.height(14.dp))
            Text(
                text = "No Cloned Apps in $profileName",
                style = MaterialTheme.typography.titleLarge,
                textAlign = TextAlign.Center
            )
            Spacer(modifier = Modifier.height(6.dp))
            Text(
                text = "Select installed user applications from the App Drawer to extract isolated ByteArray icons and provision a sandboxed clone in this container.",
                style = MaterialTheme.typography.bodyMedium,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                textAlign = TextAlign.Center
            )
            Spacer(modifier = Modifier.height(18.dp))
            Button(
                onClick = onOpenAppDrawer,
                colors = ButtonDefaults.buttonColors(
                    containerColor = ElectricCyanBright,
                    contentColor = Color(0xFF042F2E)
                ),
                shape = RoundedCornerShape(14.dp),
                modifier = Modifier.testTag("empty_state_clone_button")
            ) {
                Icon(imageVector = Icons.Default.Add, contentDescription = null)
                Spacer(modifier = Modifier.width(6.dp))
                Text(
                    text = "Select Installed Apps to Clone",
                    fontWeight = FontWeight.Bold
                )
            }
        }
    }
}

@Composable
private fun StatusFeedbackBanner(
    message: String,
    onDismiss: () -> Unit
) {
    Surface(
        shape = RoundedCornerShape(14.dp),
        color = ElectricCyan.copy(alpha = 0.16f),
        modifier = Modifier
            .fillMaxWidth()
            .border(
                1.dp,
                ElectricCyan.copy(alpha = 0.45f),
                RoundedCornerShape(14.dp)
            )
            .clickable(onClick = onDismiss)
    ) {
        Row(
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween,
            modifier = Modifier.padding(horizontal = 14.dp, vertical = 10.dp)
        ) {
            Text(
                text = message,
                style = MaterialTheme.typography.bodyMedium,
                color = Color.White,
                modifier = Modifier.weight(1f)
            )
            Spacer(modifier = Modifier.width(8.dp))
            Text(
                text = "DISMISS",
                style = MaterialTheme.typography.labelSmall,
                color = ElectricCyanBright,
                fontWeight = FontWeight.Bold
            )
        }
    }
}
