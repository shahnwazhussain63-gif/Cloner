package com.example.ui

import android.content.Intent
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.DeleteOutline
import androidx.compose.material.icons.filled.FolderZip
import androidx.compose.material.icons.filled.Key
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.Memory
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.RocketLaunch
import androidx.compose.material.icons.filled.Terminal
import androidx.compose.material.icons.filled.VerifiedUser
import androidx.compose.material3.AssistChip
import androidx.compose.material3.AssistChipDefaults
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import com.example.data.ClonedAppEntity
import com.example.data.IconByteVault
import com.example.sdk.ActivationStatus
import com.example.sdk.SdkEngineState
import com.example.sdk.SdkLaunchSession
import com.example.ui.theme.AmberWarning
import com.example.ui.theme.CrimsonError
import com.example.ui.theme.ElectricCyan
import com.example.ui.theme.ElectricCyanBright
import com.example.ui.theme.EmeraldActive
import com.example.ui.theme.RoyalIndigo

/**
 * Renders an application icon strictly from an isolated `ByteArray` buffer,
 * preventing direct `PackageManager` Drawable rendering tree retention in UI memory.
 */
@Composable
fun ByteArrayAppIcon(
    iconBytes: ByteArray,
    iconByteHash: String,
    appName: String,
    modifier: Modifier = Modifier,
    size: Dp = 56.dp,
    badgeText: String? = null,
    badgeColor: Color = ElectricCyan
) {
    val decodedBitmap = remember(iconByteHash, iconBytes.size) {
        IconByteVault.byteArrayToImageBitmap(iconBytes)
    }

    Box(modifier = modifier.size(size)) {
        if (decodedBitmap != null) {
            Image(
                bitmap = decodedBitmap,
                contentDescription = "$appName isolated ByteArray icon",
                contentScale = ContentScale.Crop,
                modifier = Modifier
                    .matchParentSize()
                    .clip(RoundedCornerShape(size * 0.26f))
                    .background(MaterialTheme.colorScheme.surfaceVariant)
                    .border(
                        width = 1.dp,
                        color = Color.White.copy(alpha = 0.14f),
                        shape = RoundedCornerShape(size * 0.26f)
                    )
            )
        } else {
            Box(
                contentAlignment = Alignment.Center,
                modifier = Modifier
                    .matchParentSize()
                    .clip(RoundedCornerShape(size * 0.26f))
                    .background(
                        Brush.linearGradient(
                            listOf(ElectricCyan, RoyalIndigo)
                        )
                    )
            ) {
                Text(
                    text = appName.take(2).uppercase(),
                    style = MaterialTheme.typography.titleMedium,
                    color = Color.White,
                    fontWeight = FontWeight.Bold
                )
            }
        }

        if (!badgeText.isNullOrBlank()) {
            Surface(
                color = badgeColor,
                shape = RoundedCornerShape(6.dp),
                shadowElevation = 4.dp,
                modifier = Modifier
                    .align(Alignment.BottomEnd)
                    .border(1.dp, Color(0xFF0B1120), RoundedCornerShape(6.dp))
            ) {
                Text(
                    text = badgeText,
                    style = MaterialTheme.typography.labelSmall,
                    color = Color(0xFF042F2E),
                    fontWeight = FontWeight.ExtraBold,
                    modifier = Modifier.padding(horizontal = 4.dp, vertical = 1.dp)
                )
            }
        }
    }
}

/**
 * Interactive dialog for `MetaActivationManager` (`activateSdk(key)`, `getActivationStatus()`,
 * `.aar` binary inspection, and `.aar` runtime bridge telemetry).
 */
@OptIn(ExperimentalLayoutApi::class)
@Composable
fun SdkActivationDialog(
    sdkState: SdkEngineState,
    aarReport: AarBinaryReport,
    onActivateKey: (String) -> Boolean,
    onDeactivateForTesting: () -> Unit,
    onRefreshStatus: () -> Unit,
    onDismiss: () -> Unit
) {
    var inputKey by remember(sdkState.licenseKey) {
        mutableStateOf(
            sdkState.licenseKey.ifEmpty { "META-CORE-2026-ENT-994A" }
        )
    }
    var localFeedback by remember { mutableStateOf<String?>(null) }

    Dialog(
        onDismissRequest = onDismiss,
        properties = DialogProperties(usePlatformDefaultWidth = false)
    ) {
        Surface(
            shape = RoundedCornerShape(24.dp),
            color = MaterialTheme.colorScheme.surface,
            tonalElevation = 8.dp,
            modifier = Modifier
                .fillMaxWidth(0.94f)
                .border(
                    width = 1.dp,
                    color = MaterialTheme.colorScheme.outline.copy(alpha = 0.5f),
                    shape = RoundedCornerShape(24.dp)
                )
        ) {
            Column(
                modifier = Modifier
                    .padding(20.dp)
                    .verticalScroll(rememberScrollState())
            ) {
                // Header
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween,
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Box(
                            contentAlignment = Alignment.Center,
                            modifier = Modifier
                                .size(42.dp)
                                .clip(RoundedCornerShape(12.dp))
                                .background(MaterialTheme.colorScheme.primaryContainer)
                        ) {
                            Icon(
                                imageVector = Icons.Default.Memory,
                                contentDescription = "SDK Bridge",
                                tint = MaterialTheme.colorScheme.primary
                            )
                        }
                        Spacer(modifier = Modifier.width(12.dp))
                        Column {
                            Text(
                                text = "MetaActivationManager",
                                style = MaterialTheme.typography.titleMedium,
                                fontWeight = FontWeight.Bold
                            )
                            Text(
                                text = sdkState.aarVersion,
                                style = MaterialTheme.typography.labelSmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                    }

                    IconButton(
                        onClick = onDismiss,
                        modifier = Modifier.testTag("close_sdk_dialog_button")
                    ) {
                        Icon(
                            imageVector = Icons.Default.Close,
                            contentDescription = "Close SDK Dialog"
                        )
                    }
                }

                Spacer(modifier = Modifier.height(12.dp))

                // 2-Part APK Architecture Breakdown (.aar SDK + separated ui(src))
                Surface(
                    shape = RoundedCornerShape(14.dp),
                    color = Color(0xFF070B14),
                    modifier = Modifier
                        .fillMaxWidth()
                        .border(
                            1.dp,
                            ElectricCyan.copy(alpha = 0.35f),
                            RoundedCornerShape(14.dp)
                        )
                ) {
                    Column(
                        verticalArrangement = Arrangement.spacedBy(5.dp),
                        modifier = Modifier.padding(12.dp)
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(
                                imageVector = Icons.Default.FolderZip,
                                contentDescription = null,
                                tint = ElectricCyanBright,
                                modifier = Modifier.size(16.dp)
                            )
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(
                                text = "2-PART MODULAR APK • SDK (.aar) + UI (src)",
                                style = MaterialTheme.typography.labelSmall,
                                color = ElectricCyanBright,
                                fontWeight = FontWeight.ExtraBold
                            )
                        }
                        TelemetryRow("Part 1 (SDK .aar)", aarReport.sdkModuleSource)
                        TelemetryRow("Compiled Archive", "app/libs/${aarReport.fileName}")
                        TelemetryRow("Part 2 (UI src)", aarReport.uiConsumerSource)
                        TelemetryRow("Gradle Binding", aarReport.gradleDependencyLine)
                        TelemetryRow(
                            "AAR Binary Size",
                            "${AarBinaryInspector.formatBytes(aarReport.totalSizeBytes)} • ${aarReport.sha256Hex}"
                        )
                        if (aarReport.entries.isNotEmpty()) {
                            TelemetryRow(
                                "AAR Entries",
                                aarReport.entries.joinToString(", ") { it.name }
                            )
                        }
                    }
                }

                Spacer(modifier = Modifier.height(12.dp))

                // Current Status Banner
                val isSdkActive = sdkState.status == ActivationStatus.ACTIVE
                val statusColor = when (sdkState.status) {
                    ActivationStatus.ACTIVE -> EmeraldActive
                    ActivationStatus.UNLICENSED -> AmberWarning
                    ActivationStatus.INVALID_KEY -> CrimsonError
                }

                Surface(
                    shape = RoundedCornerShape(14.dp),
                    color = statusColor.copy(alpha = 0.12f),
                    modifier = Modifier
                        .fillMaxWidth()
                        .border(
                            1.dp,
                            statusColor.copy(alpha = 0.4f),
                            RoundedCornerShape(14.dp)
                        )
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween,
                        modifier = Modifier.padding(horizontal = 14.dp, vertical = 10.dp)
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(
                                imageVector = if (isSdkActive) Icons.Default.VerifiedUser else Icons.Default.Lock,
                                contentDescription = "Activation Status",
                                tint = statusColor,
                                modifier = Modifier.size(20.dp)
                            )
                            Spacer(modifier = Modifier.width(8.dp))
                            Column {
                                Text(
                                    text = "getActivationStatus()",
                                    style = MaterialTheme.typography.labelSmall,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                                Text(
                                    text = sdkState.status.label,
                                    style = MaterialTheme.typography.labelLarge,
                                    color = statusColor,
                                    fontWeight = FontWeight.Bold
                                )
                            }
                        }

                        TextButton(
                            onClick = onRefreshStatus,
                            modifier = Modifier.testTag("query_sdk_status_button")
                        ) {
                            Text("Poll Status")
                        }
                    }
                }

                Spacer(modifier = Modifier.height(12.dp))

                // Key Input
                OutlinedTextField(
                    value = inputKey,
                    onValueChange = {
                        inputKey = it
                        localFeedback = null
                    },
                    label = { Text("SDK Activation Key (.aar Bridge)") },
                    placeholder = { Text("META-CORE-2026-PRO") },
                    singleLine = true,
                    leadingIcon = {
                        Icon(
                            imageVector = Icons.Default.Key,
                            contentDescription = "Key Icon"
                        )
                    },
                    shape = RoundedCornerShape(14.dp),
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("sdk_key_input")
                )

                Spacer(modifier = Modifier.height(8.dp))

                // Quick Preset Keys
                Text(
                    text = "Quick Preset Keys:",
                    style = MaterialTheme.typography.labelSmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
                FlowRow(
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    listOf("META-CORE-2026-ENT-994A", "CLONE-PRO-2026-V4").forEach { preset ->
                        AssistChip(
                            onClick = { inputKey = preset },
                            label = {
                                Text(
                                    text = preset,
                                    style = MaterialTheme.typography.labelSmall
                                )
                            },
                            colors = AssistChipDefaults.assistChipColors(
                                containerColor = MaterialTheme.colorScheme.surfaceVariant
                            )
                        )
                    }
                }

                AnimatedVisibility(visible = localFeedback != null) {
                    Text(
                        text = localFeedback.orEmpty(),
                        style = MaterialTheme.typography.bodyMedium,
                        color = if (isSdkActive) EmeraldActive else CrimsonError,
                        modifier = Modifier.padding(top = 6.dp)
                    )
                }

                Spacer(modifier = Modifier.height(10.dp))

                // Action Buttons
                Row(
                    horizontalArrangement = Arrangement.spacedBy(10.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    OutlinedButton(
                        onClick = {
                            onDeactivateForTesting()
                            localFeedback = "SDK locked. Try launching a cloned app to test guard."
                        },
                        shape = RoundedCornerShape(12.dp),
                        modifier = Modifier
                            .weight(1f)
                            .testTag("sdk_lock_test_button")
                    ) {
                        Text("Simulate Lock")
                    }

                    Button(
                        onClick = {
                            val ok = onActivateKey(inputKey)
                            localFeedback = if (ok) {
                                "activateSdk() succeeded! Engine ready."
                            } else {
                                "activateSdk() rejected key format."
                            }
                        },
                        shape = RoundedCornerShape(12.dp),
                        modifier = Modifier
                            .weight(1f)
                            .testTag("sdk_activate_submit_button")
                    ) {
                        Text("activateSdk()")
                    }
                }

                Spacer(modifier = Modifier.height(14.dp))

                // Live .aar SDK Call Log
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Icon(
                        imageVector = Icons.Default.Terminal,
                        contentDescription = "Bridge Logs",
                        tint = MaterialTheme.colorScheme.primary,
                        modifier = Modifier.size(16.dp)
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(
                        text = "Live meta-activation-sdk.aar Bridge Telemetry",
                        style = MaterialTheme.typography.labelLarge,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }

                Spacer(modifier = Modifier.height(8.dp))

                LazyColumn(
                    verticalArrangement = Arrangement.spacedBy(6.dp),
                    modifier = Modifier
                        .fillMaxWidth()
                        .heightIn(min = 90.dp, max = 145.dp)
                        .clip(RoundedCornerShape(12.dp))
                        .background(Color(0xFF070B14))
                        .padding(10.dp)
                ) {
                    items(sdkState.logs, key = { it.id }) { entry ->
                        Column {
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.SpaceBetween,
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                Text(
                                    text = entry.methodSignature,
                                    style = MaterialTheme.typography.labelSmall,
                                    color = if (entry.isSuccess) ElectricCyan else CrimsonError,
                                    fontWeight = FontWeight.Bold
                                )
                                Text(
                                    text = entry.timestamp,
                                    style = MaterialTheme.typography.labelSmall,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.7f)
                                )
                            }
                            Text(
                                text = entry.detail,
                                style = MaterialTheme.typography.labelSmall,
                                color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.85f)
                            )
                        }
                    }
                }
            }
        }
    }
}

/**
 * Dialog shown when creating a new isolated Profile Container (e.g., "Account #4").
 */
@Composable
fun CreateProfileContainerDialog(
    nextAccountIndex: Int,
    onCreateProfile: (String, String) -> Unit,
    onDismiss: () -> Unit
) {
    var name by remember { mutableStateOf("Account #$nextAccountIndex") }
    var tag by remember { mutableStateOf("ISOLATED SANDBOX") }

    Dialog(onDismissRequest = onDismiss) {
        Surface(
            shape = RoundedCornerShape(24.dp),
            color = MaterialTheme.colorScheme.surface,
            tonalElevation = 8.dp,
            modifier = Modifier
                .fillMaxWidth()
                .border(
                    1.dp,
                    MaterialTheme.colorScheme.outline.copy(alpha = 0.5f),
                    RoundedCornerShape(24.dp)
                )
        ) {
            Column(modifier = Modifier.padding(20.dp)) {
                Text(
                    text = "New Account Container",
                    style = MaterialTheme.typography.titleLarge
                )
                Spacer(modifier = Modifier.height(6.dp))
                Text(
                    text = "Provision an isolated virtual storage namespace for multi-account app cloning.",
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )

                Spacer(modifier = Modifier.height(16.dp))

                OutlinedTextField(
                    value = name,
                    onValueChange = { name = it },
                    label = { Text("Profile Session Name") },
                    placeholder = { Text("e.g. Account #$nextAccountIndex") },
                    singleLine = true,
                    shape = RoundedCornerShape(12.dp),
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("new_profile_name_input")
                )

                Spacer(modifier = Modifier.height(12.dp))

                OutlinedTextField(
                    value = tag,
                    onValueChange = { tag = it },
                    label = { Text("Container Security Tag") },
                    placeholder = { Text("e.g. WORK / SECONDARY / STEALTH") },
                    singleLine = true,
                    shape = RoundedCornerShape(12.dp),
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("new_profile_tag_input")
                )

                Spacer(modifier = Modifier.height(20.dp))

                Row(
                    horizontalArrangement = Arrangement.End,
                    modifier = Modifier.fillMaxWidth()
                ) {
                    TextButton(onClick = onDismiss) {
                        Text("Cancel")
                    }
                    Spacer(modifier = Modifier.width(8.dp))
                    Button(
                        onClick = { onCreateProfile(name, tag) },
                        shape = RoundedCornerShape(12.dp),
                        modifier = Modifier.testTag("confirm_create_profile_button")
                    ) {
                        Text("Create Container")
                    }
                }
            }
        }
    }
}

/**
 * Displays the live virtualized container handshake returned by
 * `MetaActivationManager.launchApp(packageName)` when a cloned app is tapped.
 */
@Composable
fun ActiveLaunchSessionDialog(
    session: SdkLaunchSession,
    onDismiss: () -> Unit
) {
    val context = LocalContext.current

    Dialog(onDismissRequest = onDismiss) {
        Surface(
            shape = RoundedCornerShape(24.dp),
            color = MaterialTheme.colorScheme.surface,
            tonalElevation = 10.dp,
            modifier = Modifier
                .fillMaxWidth()
                .border(
                    1.5.dp,
                    ElectricCyan.copy(alpha = 0.55f),
                    RoundedCornerShape(24.dp)
                )
        ) {
            Column(
                modifier = Modifier.padding(20.dp)
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    Box(
                        contentAlignment = Alignment.Center,
                        modifier = Modifier
                            .size(48.dp)
                            .clip(CircleShape)
                            .background(EmeraldActive.copy(alpha = 0.16f))
                    ) {
                        Icon(
                            imageVector = Icons.Default.RocketLaunch,
                            contentDescription = "Virtual Launch Active",
                            tint = EmeraldActive,
                            modifier = Modifier.size(26.dp)
                        )
                    }
                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            text = "Virtual Container Active",
                            style = MaterialTheme.typography.titleMedium,
                            color = EmeraldActive,
                            fontWeight = FontWeight.Bold
                        )
                        Text(
                            text = "MetaActivationManager.launchApp(\"${session.packageName}\")",
                            style = MaterialTheme.typography.labelSmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis
                        )
                    }
                }

                Spacer(modifier = Modifier.height(16.dp))

                Surface(
                    shape = RoundedCornerShape(14.dp),
                    color = Color(0xFF070B14),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(
                        verticalArrangement = Arrangement.spacedBy(8.dp),
                        modifier = Modifier.padding(14.dp)
                    ) {
                        TelemetryRow("Cloned App", session.appName)
                        TelemetryRow("SDK Bridge", "meta-activation-sdk.aar -> ui(src)")
                        TelemetryRow("Container Session", "${session.profileName} (${session.sessionId})")
                        TelemetryRow("Virtual UID / PID", "u0_a${session.virtualUid} • PID ${session.virtualPid}")
                        TelemetryRow(
                            "ByteArray Icon Vault",
                            "${session.iconByteHash} (${IconByteVault.formatByteSize(session.iconByteSize)})"
                        )
                        TelemetryRow("Isolated VFS Root", session.sandboxDataDir)
                    }
                }

                Spacer(modifier = Modifier.height(18.dp))

                Row(
                    horizontalArrangement = Arrangement.spacedBy(10.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    OutlinedButton(
                        onClick = onDismiss,
                        shape = RoundedCornerShape(12.dp),
                        modifier = Modifier
                            .weight(1f)
                            .testTag("dismiss_launch_session_button")
                    ) {
                        Text("Close Monitor")
                    }

                    Button(
                        onClick = {
                            try {
                                val launchIntent = context.packageManager
                                    .getLaunchIntentForPackage(session.packageName)
                                    ?.apply {
                                        addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                                        putExtra("META_VIRTUAL_PROFILE_ID", session.profileId)
                                        putExtra("META_VIRTUAL_UID", session.virtualUid)
                                    }
                                if (launchIntent != null) {
                                    context.startActivity(launchIntent)
                                }
                            } catch (_: Exception) {
                            }
                            onDismiss()
                        },
                        colors = ButtonDefaults.buttonColors(
                            containerColor = ElectricCyan,
                            contentColor = Color(0xFF042F2E)
                        ),
                        shape = RoundedCornerShape(12.dp),
                        modifier = Modifier
                            .weight(1f)
                            .testTag("launch_host_activity_button")
                    ) {
                        Icon(
                            imageVector = Icons.Default.PlayArrow,
                            contentDescription = null,
                            modifier = Modifier.size(18.dp)
                        )
                        Spacer(modifier = Modifier.width(4.dp))
                        Text("Open App")
                    }
                }
            }
        }
    }
}

/**
 * Inspection modal for a cloned app card (shows isolated `ByteArray` stats, launch button, and remove button).
 */
@Composable
fun CloneInspectionDialog(
    clone: ClonedAppEntity,
    profileDisplayName: String,
    onLaunch: () -> Unit,
    onRemove: () -> Unit,
    onDismiss: () -> Unit
) {
    Dialog(onDismissRequest = onDismiss) {
        Surface(
            shape = RoundedCornerShape(24.dp),
            color = MaterialTheme.colorScheme.surface,
            tonalElevation = 8.dp,
            modifier = Modifier
                .fillMaxWidth()
                .border(
                    1.dp,
                    MaterialTheme.colorScheme.outline.copy(alpha = 0.5f),
                    RoundedCornerShape(24.dp)
                )
        ) {
            Column(modifier = Modifier.padding(20.dp)) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(14.dp)
                ) {
                    ByteArrayAppIcon(
                        iconBytes = clone.iconBytes,
                        iconByteHash = clone.iconByteHash,
                        appName = clone.appName,
                        size = 60.dp
                    )
                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            text = clone.appName,
                            style = MaterialTheme.typography.titleLarge,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis
                        )
                        Text(
                            text = clone.packageName,
                            style = MaterialTheme.typography.labelSmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis
                        )
                        Text(
                            text = "v${clone.versionName} • $profileDisplayName",
                            style = MaterialTheme.typography.bodyMedium,
                            color = ElectricCyan
                        )
                    }
                }

                Spacer(modifier = Modifier.height(16.dp))

                Surface(
                    shape = RoundedCornerShape(14.dp),
                    color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.55f),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(
                        verticalArrangement = Arrangement.spacedBy(6.dp),
                        modifier = Modifier.padding(12.dp)
                    ) {
                        TelemetryRow("Icon Memory Mode", "Segregated ByteArray BLOB")
                        TelemetryRow("Icon Byte Signature", clone.iconByteHash)
                        TelemetryRow("Buffer Footprint", IconByteVault.formatByteSize(clone.iconByteSize))
                        TelemetryRow("Container Launches", "${clone.launchCount} session(s)")
                    }
                }

                Spacer(modifier = Modifier.height(18.dp))

                Row(
                    horizontalArrangement = Arrangement.spacedBy(10.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    OutlinedButton(
                        onClick = onRemove,
                        colors = ButtonDefaults.outlinedButtonColors(
                            contentColor = CrimsonError
                        ),
                        shape = RoundedCornerShape(12.dp),
                        modifier = Modifier
                            .weight(1f)
                            .testTag("remove_clone_button")
                    ) {
                        Icon(
                            imageVector = Icons.Default.DeleteOutline,
                            contentDescription = null,
                            modifier = Modifier.size(18.dp)
                        )
                        Spacer(modifier = Modifier.width(4.dp))
                        Text("Remove")
                    }

                    Button(
                        onClick = {
                            onDismiss()
                            onLaunch()
                        },
                        shape = RoundedCornerShape(12.dp),
                        modifier = Modifier
                            .weight(1f)
                            .testTag("inspect_launch_clone_button")
                    ) {
                        Icon(
                            imageVector = Icons.Default.PlayArrow,
                            contentDescription = null,
                            modifier = Modifier.size(18.dp)
                        )
                        Spacer(modifier = Modifier.width(4.dp))
                        Text("Launch")
                    }
                }
            }
        }
    }
}

@Composable
internal fun TelemetryRow(label: String, value: String) {
    Row(
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.Top,
        modifier = Modifier.fillMaxWidth()
    ) {
        Text(
            text = label,
            style = MaterialTheme.typography.labelSmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
            modifier = Modifier.weight(0.42f)
        )
        Text(
            text = value,
            style = MaterialTheme.typography.labelSmall.copy(fontFamily = FontFamily.Monospace),
            color = MaterialTheme.colorScheme.onSurface,
            fontWeight = FontWeight.SemiBold,
            modifier = Modifier.weight(0.58f)
        )
    }
}
