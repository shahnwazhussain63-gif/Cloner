package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.slideInHorizontally
import androidx.compose.animation.slideOutHorizontally
import androidx.compose.animation.togetherWith
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import com.example.sdk.MetaActivationManager
import com.example.ui.ActiveLaunchSessionDialog
import com.example.ui.AppDrawerScreen
import com.example.ui.CloneInspectionDialog
import com.example.ui.CreateProfileContainerDialog
import com.example.ui.DashboardScreen
import com.example.ui.LoaderScreen
import com.example.ui.LoaderViewModel
import com.example.ui.SdkActivationDialog
import com.example.ui.theme.MyApplicationTheme

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            MyApplicationTheme {
                Surface(
                    modifier = Modifier.fillMaxSize(),
                    color = MaterialTheme.colorScheme.background
                ) {
                    CloneVaultLoaderApp()
                }
            }
        }
    }
}

@Composable
fun CloneVaultLoaderApp(
    loaderViewModel: LoaderViewModel = viewModel(
        factory = LoaderViewModel.Factory(LocalContext.current.applicationContext)
    )
) {
    val uiState by loaderViewModel.uiState.collectAsStateWithLifecycle()

    AnimatedContent(
        targetState = uiState.currentScreen,
        transitionSpec = {
            if (targetState is LoaderScreen.AppDrawer) {
                (slideInHorizontally { width -> width / 3 } + fadeIn()) togetherWith
                    (slideOutHorizontally { width -> -width / 4 } + fadeOut())
            } else {
                (slideInHorizontally { width -> -width / 4 } + fadeIn()) togetherWith
                    (slideOutHorizontally { width -> width / 3 } + fadeOut())
            }
        },
        label = "LoaderScreenTransition"
    ) { screen ->
        when (screen) {
            is LoaderScreen.Dashboard -> {
                DashboardScreen(
                    uiState = uiState,
                    onSwitchProfile = loaderViewModel::switchProfile,
                    onOpenNewProfileDialog = { loaderViewModel.setShowCreateProfileDialog(true) },
                    onOpenAppDrawer = loaderViewModel::openAppDrawer,
                    onLaunchClone = loaderViewModel::launchClonedApp,
                    onInspectClone = { loaderViewModel.setInspectingClone(it) },
                    onOpenSdkDialog = { loaderViewModel.setShowSdkDialog(true) },
                    onDismissBanner = loaderViewModel::clearStatusBanner
                )
            }

            is LoaderScreen.AppDrawer -> {
                AppDrawerScreen(
                    uiState = uiState,
                    onNavigateBack = loaderViewModel::navigateBackToDashboard,
                    onSearchQueryChange = loaderViewModel::setDrawerSearchQuery,
                    onFilterModeChange = loaderViewModel::setOnlyUserAppsFilter,
                    onToggleSelectPackage = loaderViewModel::togglePackageSelection,
                    onSelectAllUncloned = loaderViewModel::selectAllUnclonedVisibleApps,
                    onClearSelection = loaderViewModel::clearSelection,
                    onCloneSingleApp = loaderViewModel::cloneSingleApp,
                    onCloneSelectedApps = loaderViewModel::cloneSelectedAppsAndReturn,
                    onRefreshInstalledApps = loaderViewModel::refreshInstalledApps
                )
            }
        }
    }

    // MetaActivationManager (.aar SDK Bridge) Modal
    if (uiState.showSdkDialog) {
        SdkActivationDialog(
            sdkState = uiState.sdkEngineState,
            aarReport = uiState.aarBinaryReport,
            onActivateKey = loaderViewModel::activateSdk,
            onDeactivateForTesting = loaderViewModel::deactivateSdkForTesting,
            onRefreshStatus = { MetaActivationManager.getActivationStatus() },
            onDismiss = { loaderViewModel.setShowSdkDialog(false) }
        )
    }

    // New Account Container Creation Dialog
    if (uiState.showCreateProfileDialog) {
        CreateProfileContainerDialog(
            nextAccountIndex = uiState.profiles.size + 1,
            onCreateProfile = loaderViewModel::createNewProfile,
            onDismiss = { loaderViewModel.setShowCreateProfileDialog(false) }
        )
    }

    // Cloned App Inspection & Removal Modal
    val inspecting = uiState.inspectingClone
    if (inspecting != null) {
        CloneInspectionDialog(
            clone = inspecting,
            profileDisplayName = uiState.activeProfile.displayName,
            onLaunch = { loaderViewModel.launchClonedApp(inspecting) },
            onRemove = { loaderViewModel.removeClonedApp(inspecting) },
            onDismiss = { loaderViewModel.setInspectingClone(null) }
        )
    }

    // Active Virtual Launch Session Telemetry Modal (`MetaActivationManager.launchApp(packageName)`)
    val activeLaunchSession = uiState.sdkEngineState.activeSession
    if (activeLaunchSession != null) {
        ActiveLaunchSessionDialog(
            session = activeLaunchSession,
            onDismiss = loaderViewModel::dismissActiveLaunchSession
        )
    }
}
