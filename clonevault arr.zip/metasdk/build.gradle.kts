plugins {
  alias(libs.plugins.android.library)
}

android {
  namespace = "com.example.sdk"
  compileSdk { version = release(36) { minorApiLevel = 1 } }

  defaultConfig {
    minSdk = 24
    consumerProguardFiles("consumer-rules.pro")
  }

  buildTypes {
    release {
      isMinifyEnabled = false
    }
    debug {
      isMinifyEnabled = false
    }
  }

  compileOptions {
    sourceCompatibility = JavaVersion.VERSION_11
    targetCompatibility = JavaVersion.VERSION_11
  }
}

dependencies {
  implementation(libs.androidx.core.ktx)
  implementation(libs.kotlinx.coroutines.android)
  implementation(libs.kotlinx.coroutines.core)
}

val copySdkAarToLibs by tasks.registering(Copy::class) {
  dependsOn("assembleRelease")
  from(layout.buildDirectory.file("outputs/aar/metasdk-release.aar"))
  into(layout.projectDirectory.dir("../app/libs"))
  rename { "meta-activation-sdk.aar" }
}

val copySdkAarToAssets by tasks.registering(Copy::class) {
  dependsOn("assembleRelease")
  from(layout.buildDirectory.file("outputs/aar/metasdk-release.aar"))
  into(layout.projectDirectory.dir("../app/src/main/assets"))
  rename { "meta-activation-sdk.aar" }
}

val exportSdkAar by tasks.registering {
  dependsOn(copySdkAarToLibs, copySdkAarToAssets)
}
