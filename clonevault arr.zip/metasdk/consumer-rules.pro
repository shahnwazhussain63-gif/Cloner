# Keep public SDK API classes in the compiled .aar archive
-keep class com.example.sdk.** { *; }
